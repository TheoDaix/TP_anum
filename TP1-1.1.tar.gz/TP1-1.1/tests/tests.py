def test:
    pass