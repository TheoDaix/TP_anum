* Complément d'infos sur le code (analyse math,...)
